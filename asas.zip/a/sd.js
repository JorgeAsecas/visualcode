
function mensaje(texto) {
    document.write(texto);
 }
